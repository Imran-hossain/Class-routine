import React from "react";
import List from "./components/List";
import Card from "./components/Card";

function App() {
  return (
    <div className="App">
      <main className="flexbox">
        <List id="list-1" className="list">
          <Card id="card-1" className="card" draggable="true">
            <p>Shoikoth</p>
          </Card>
        </List>
        <List id="list-2" className="list">
          <Card id="card-2" className="card" draggable="true">
            <p>Rupa</p>
          </Card>
        </List>

        <List id="list-3" className="list">
          <Card id="card-3" className="card" draggable="true">
            <p>Rajeeb</p>
          </Card>
        </List>

        <List id="list-4" className="list">
          <Card id="card-4" className="card" draggable="true">
            <p>Sumi</p>
          </Card>
        </List>

        <List id="list-5" className="list">
          <Card id="card-5" className="card" draggable="true">
            <p>Mahid</p>
          </Card>
        </List>
      </main>
    </div>
  );
}

export default App;
